using centermuebles_tesis.modelos;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Habilitamos controladores API
builder.Services.AddControllers();

// Habilitamos CORS para permitir conexiones desde cualquier frontend
builder.Services.AddCors(options =>
{
    options.AddPolicy("PermitirTodo", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

// Configuramos el contexto de la base de datos usando la cadena "DefaultConnection"
builder.Services.AddDbContext<CentermueblesContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

var app = builder.Build();

// Habilitamos CORS con la pol�tica definida
app.UseCors("PermitirTodo");

// Habilitamos archivos est�ticos (HTML, CSS, JS, im�genes)
app.UseStaticFiles();

// Configuramos ruteo
app.UseRouting();

// Mapear API Controllers
app.UseEndpoints(endpoints =>
{
    endpoints.MapControllers();
});

// Mapear la ra�z "/" a index.html
app.MapGet("/", (IWebHostEnvironment env) =>
{
    var path = Path.Combine(env.ContentRootPath, "wwwroot", "index.html");
    return Results.File(path, "text/html");
});


// Ejecutar la aplicaci�n
app.Run();

