﻿using Microsoft.AspNetCore.Mvc;
using centermuebles_tesis.modelos;
using Microsoft.EntityFrameworkCore;

namespace centermuebles_tesis.controladores
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductosController : ControllerBase
    {
        // Variable para acceder a la base de datos
        private readonly CentermueblesContext _context;

        // Constructor: se ejecuta cuando se crea el controlador
        public ProductosController(CentermueblesContext context)
        {
            _context = context;
        }

        // GET: api/productos → devuelve todos los productos reales desde la base
        [HttpGet]
        public IActionResult ObtenerProductos()
        {
            var productos = _context.Productos.ToList(); // Lee desde SQL Server
            return Ok(productos); // Devuelve la lista al front
        }
        // GET: api/productos/7 → devuelve el producto con IdProducto = 7
        [HttpGet("{id}")]
        public IActionResult ObtenerProductoPorId(int id)
        {
            var producto = _context.Productos.FirstOrDefault(p => p.IdProducto == id);

            if (producto == null)
            {
                return NotFound($"No se encontró un producto con ID {id}");
            }

            return Ok(producto);
        }
        // DELETE: api/productos/7 → borra el producto con IdProducto = 7
        [HttpDelete("{id}")]
        public IActionResult EliminarProducto(int id)
        {
            var producto = _context.Productos.FirstOrDefault(p => p.IdProducto == id);

            if (producto == null)
            {
                return NotFound(new { mensaje = $"No se encontró un producto con ID {id}" });
            }

            _context.Productos.Remove(producto);
            _context.SaveChanges();

            return Ok(new { mensaje = $"Producto '{producto.Nombre}' eliminado correctamente" });
        }
        // PUT: api/productos/7  → actualiza los datos del producto con IdProducto = 7
        [HttpPut("{id}")]
        public IActionResult ActualizarProducto(int id, [FromBody] Producto productoActualizado)
        {
            var productoExistente = _context.Productos.FirstOrDefault(p => p.IdProducto == id);

            if (productoExistente == null)
            {
                return NotFound(new { mensaje = $"No se encontró un producto con ID {id}" });
            }

            // Actualizamos campos (podés agregar o quitar según lo que quieras permitir editar)
            productoExistente.Nombre = productoActualizado.Nombre;
            productoExistente.Precio = productoActualizado.Precio;
            productoExistente.IdCategoria = productoActualizado.IdCategoria;
            productoExistente.IdSubcategoria = productoActualizado.IdSubcategoria;
            productoExistente.RutaImagen = productoActualizado.RutaImagen;
            productoExistente.Stock = productoActualizado.Stock;

            _context.SaveChanges();

            return Ok(new { mensaje = $"Producto con ID {id} actualizado correctamente" });
        }

        // POST: api/productos → guarda un nuevo producto en la base
        [HttpPost]
        public IActionResult CrearProducto([FromBody] Producto nuevoProducto)
        {
            // Forzamos un valor si llega 0 (o si de alguna forma llega null)
            if (nuevoProducto.Stock <= 0)
                nuevoProducto.Stock = 10;

            // Guardamos el producto en la DB
            _context.Productos.Add(nuevoProducto); // Agrega el producto
            _context.SaveChanges(); // Guarda cambios en la base

            return Ok($"Producto guardado: {nuevoProducto.Nombre} con stock {nuevoProducto.Stock}");
        }
    }
}