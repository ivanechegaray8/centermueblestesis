﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace centermuebles_tesis.modelos;

// Contexto principal de la base de datos
public partial class CentermueblesContext : DbContext
{
    // Constructor vacío
    public CentermueblesContext()
    {
    }

    // Constructor que recibe opciones (como la cadena de conexión)
    public CentermueblesContext(DbContextOptions<CentermueblesContext> options)
        : base(options)
    {
    }

    // Tablas de la base de datos
    public virtual DbSet<Categoria> Categorias { get; set; }   // Tabla Categorias
    public virtual DbSet<Cliente> Clientes { get; set; }       // Tabla Clientes
    public virtual DbSet<DetalleVenta> DetalleVentas { get; set; } // Tabla DetalleVentas
    public virtual DbSet<Producto> Productos { get; set; }     // Tabla Productos
    public virtual DbSet<Subcategoria> Subcategorias { get; set; } // Tabla Subcategorias
    public virtual DbSet<Usuario> Usuarios { get; set; }       // Tabla Usuarios
    public virtual DbSet<Venta> Ventas { get; set; }           // Tabla Ventas

    // Configuración de la conexión a la base de datos
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    #warning To protect potentially sensitive information in your connection string, you should move it out of source code.
        => optionsBuilder.UseSqlServer("Server=localhost;Database=Centermuebles;Trusted_Connection=True;TrustServerCertificate=True;");

    // Configuración de tablas, columnas y relaciones
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Categoria>(entity =>
        {
            entity.HasKey(e => e.IdCategoria).HasName("PK__Categori__A3C02A103DE01381"); // Clave primaria
            entity.Property(e => e.Nombre)
                .HasMaxLength(50)  // Largo máximo de la columna
                .IsUnicode(false); // No usa Unicode
        });

        modelBuilder.Entity<Cliente>(entity =>
        {
            entity.HasKey(e => e.IdCliente).HasName("PK__Clientes__D594664226C05E9E");
            entity.Property(e => e.Email)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Nombre)
                .HasMaxLength(100)
                .IsUnicode(false);
        });

        modelBuilder.Entity<DetalleVenta>(entity =>
        {
            entity.HasKey(e => e.IdDetalle).HasName("PK__DetalleV__E43646A52EEA2889");
            entity.Property(e => e.PrecioUnitario).HasColumnType("decimal(10, 2)"); // Tipo decimal

            // Relación con Producto (FK)
            entity.HasOne(d => d.IdProductoNavigation).WithMany(p => p.DetalleVenta)
                .HasForeignKey(d => d.IdProducto)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__DetalleVe__IdPro__4CA06362");

            // Relación con Venta (FK)
            entity.HasOne(d => d.IdVentaNavigation).WithMany(p => p.DetalleVenta)
                .HasForeignKey(d => d.IdVenta)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__DetalleVe__IdVen__4BAC3F29");
        });

        modelBuilder.Entity<Producto>(entity =>
        {
            entity.HasKey(e => e.IdProducto).HasName("PK__Producto__09889210443968A0");
            entity.Property(e => e.Nombre)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Precio).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.RutaImagen)
                .HasMaxLength(255)
                .IsUnicode(false);

            // Relación con Categoria
            entity.HasOne(d => d.IdCategoriaNavigation).WithMany(p => p.Productos)
                .HasForeignKey(d => d.IdCategoria)
                .HasConstraintName("FK_Productos_Categorias");

            // Relación con Subcategoria
            entity.HasOne(d => d.IdSubcategoriaNavigation).WithMany(p => p.Productos)
                .HasForeignKey(d => d.IdSubcategoria)
                .HasConstraintName("FK_Productos_Subcategorias");
        });

        modelBuilder.Entity<Subcategoria>(entity =>
        {
            entity.HasKey(e => e.IdSubcategoria).HasName("PK__Subcateg__6B8582B63E5367BC");
            entity.Property(e => e.Nombre)
                .HasMaxLength(50)
                .IsUnicode(false);

            // Relación con Categoria
            entity.HasOne(d => d.IdCategoriaNavigation).WithMany(p => p.Subcategoria)
                .HasForeignKey(d => d.IdCategoria)
                .HasConstraintName("FK__Subcatego__IdCat__4222D4EF");
        });

        modelBuilder.Entity<Usuario>(entity =>
        {
            entity.HasKey(e => e.IdUsuario).HasName("PK__Usuarios__5B65BF9755567B72");
            entity.Property(e => e.Contraseña)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.NombreUsuario)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Rol)
                .HasMaxLength(20)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Venta>(entity =>
        {
            entity.HasKey(e => e.IdVenta).HasName("PK__Ventas__BC1240BD52C002B6");
            entity.Property(e => e.FechaVenta)
                .HasDefaultValueSql("(getdate())") // Fecha por defecto al crear
                .HasColumnType("datetime");

            // Relación con Cliente
            entity.HasOne(d => d.IdClienteNavigation).WithMany(p => p.Venta)
                .HasForeignKey(d => d.IdCliente)
                .HasConstraintName("FK__Ventas__IdClient__3B75D760");

            // Relación con Producto
            entity.HasOne(d => d.IdProductoNavigation).WithMany(p => p.Venta)
                .HasForeignKey(d => d.IdProducto)
                .HasConstraintName("FK__Ventas__IdProduc__3C69FB99");
        });

        // Permite agregar más configuraciones en otra parte del código
        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
