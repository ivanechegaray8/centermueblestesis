﻿using System;
using System.Collections.Generic;

namespace centermuebles_tesis.modelos;

public partial class Cliente
{
    public int IdCliente { get; set; }

    public string Nombre { get; set; } = null!;

    public string? Email { get; set; }

    public virtual ICollection<Venta> Venta { get; set; } = new List<Venta>();
}
