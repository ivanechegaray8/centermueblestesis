﻿using System;
using System.Collections.Generic;

namespace centermuebles_tesis.modelos;

public partial class Producto
{
    public int IdProducto { get; set; }

    public string Nombre { get; set; } = null!;

    public decimal Precio { get; set; }

    public int Stock { get; set; }

    public int? IdCategoria { get; set; }

    public int? IdSubcategoria { get; set; }

    public string? RutaImagen { get; set; }

    public virtual ICollection<DetalleVenta> DetalleVenta { get; set; } = new List<DetalleVenta>();

    public virtual Categoria? IdCategoriaNavigation { get; set; }

    public virtual Subcategoria? IdSubcategoriaNavigation { get; set; }

    public virtual ICollection<Venta> Venta { get; set; } = new List<Venta>();
}
