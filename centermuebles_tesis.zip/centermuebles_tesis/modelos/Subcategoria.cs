﻿using System;
using System.Collections.Generic;

namespace centermuebles_tesis.modelos;

public partial class Subcategoria
{
    public int IdSubcategoria { get; set; }

    public string Nombre { get; set; } = null!;

    public int? IdCategoria { get; set; }

    public virtual Categoria? IdCategoriaNavigation { get; set; }

    public virtual ICollection<Producto> Productos { get; set; } = new List<Producto>();
}
